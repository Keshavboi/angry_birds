package io.github.AngryBird.me;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class SettingScreen {
    private SpriteBatch batch;
    private Texture popupImage, closeButton, termsPrivacyButton, supportButton, creditsButton, eraseDataButton;
    private boolean isSettingsOpen;

    public SettingScreen(SpriteBatch batch) {
        this.batch = batch;
        popupImage = new Texture("settingbackground.png");
        closeButton = new Texture("close_button.png");
        termsPrivacyButton = new Texture("terms_privacy.png");
        supportButton = new Texture("support.png");
        creditsButton = new Texture("credit.png");
        eraseDataButton = new Texture("Erase data.png");
        isSettingsOpen = false;
    }

    public void render() {
        if (isSettingsOpen) {
            float popupX = (Gdx.graphics.getWidth() - popupImage.getWidth()) / 2;
            float popupY = (Gdx.graphics.getHeight() - popupImage.getHeight()) / 2;
            batch.draw(popupImage, popupX, popupY);
            drawSettingsPopup(popupX, popupY);
            handleTouch(popupX, popupY);
        }
    }

    private void drawSettingsPopup(float popupX, float popupY) {
        float buttonWidth = 300;
        float buttonHeight = 60;
        float buttonX = popupX + (popupImage.getWidth() - buttonWidth) / 2;
        float buttonYStart = popupY + popupImage.getHeight() - 80;

        batch.draw(termsPrivacyButton, buttonX, buttonYStart, buttonWidth, buttonHeight);
        batch.draw(supportButton, buttonX, buttonYStart - 70, buttonWidth, buttonHeight);
        batch.draw(creditsButton, buttonX, buttonYStart - 140, buttonWidth, buttonHeight);
        batch.draw(eraseDataButton, buttonX, buttonYStart - 210, buttonWidth, buttonHeight);

        float closeButtonSize = 100;
        float closeButtonX = popupX + popupImage.getWidth() - closeButtonSize - 20;
        float closeButtonY = popupY + popupImage.getHeight() - closeButtonSize - 20;
        batch.draw(closeButton, closeButtonX, closeButtonY, closeButtonSize, closeButtonSize);
    }

    private void handleTouch(float popupX, float popupY) {
        if (Gdx.input.isTouched()) {
            float touchX = Gdx.input.getX();
            float touchY = Gdx.graphics.getHeight() - Gdx.input.getY();

            float closeButtonSize = 70;
            float closeButtonX = popupX + popupImage.getWidth() - closeButtonSize - 10;
            float closeButtonY = popupY + popupImage.getHeight() - closeButtonSize - 10;

            if (touchX >= closeButtonX && touchX <= closeButtonX + closeButtonSize && touchY >= closeButtonY && touchY <= closeButtonY + closeButtonSize) {
                isSettingsOpen = false;
            }
        }
    }

    public void toggle() {
        isSettingsOpen = !isSettingsOpen;
    }

    public void dispose() {
        popupImage.dispose();
        closeButton.dispose();
        termsPrivacyButton.dispose();
        supportButton.dispose();
        creditsButton.dispose();
        eraseDataButton.dispose();
    }
}

