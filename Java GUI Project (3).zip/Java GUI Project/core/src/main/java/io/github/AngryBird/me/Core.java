package io.github.AngryBird.me;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

public class Core extends ApplicationAdapter {
    private SpriteBatch batch;
    private Texture loadingImage;
    private Texture mainScreenImage;
    private Texture homeIcon, startGameButton, newGameButton, levelsButton, settingsIcon, musicButton;
    private float timeElapsed;
    private boolean isLoading;
    private SettingScreen settingScreen;

    private float homeIconX, homeIconY, musicButtonX, musicButtonY, settingsIconX, settingsIconY;

    @Override
    public void create() {
        batch = new SpriteBatch();
        loadingImage = new Texture("1.png");
        mainScreenImage = new Texture("Angry Bird 1.png");
        timeElapsed = 0f;
        isLoading = true;

        homeIcon = new Texture("home_icon.png");
        startGameButton = new Texture("start_game_button.jpg");
        newGameButton = new Texture("new_game_button.png");
        levelsButton = new Texture("levels_button.png");
        settingsIcon = new Texture("settings_icon.jpg");
        musicButton = new Texture("music_button.jpg");

        settingScreen = new SettingScreen(batch);

        homeIconX = 30;
        homeIconY = Gdx.graphics.getHeight() - 100;
        musicButtonX = Gdx.graphics.getWidth() - 100;
        musicButtonY = Gdx.graphics.getHeight() - 100;
        settingsIconX = 20;
        settingsIconY = 30;
    }

    @Override
    public void render() {
        ScreenUtils.clear(0.15f, 0.15f, 0.2f, 1f);
        batch.begin();

        timeElapsed += Gdx.graphics.getDeltaTime();

        if (isLoading) {
            batch.draw(loadingImage, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
            if (timeElapsed > 1) {
                isLoading = false;
                timeElapsed = 0;
            }
        } else {
            batch.draw(mainScreenImage, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
            batch.draw(homeIcon, homeIconX, homeIconY, 84, 84);
            batch.draw(settingsIcon, settingsIconX, settingsIconY, 84, 84);
            batch.draw(musicButton, musicButtonX, musicButtonY, 84, 84);

            float buttonWidth = 200;
            float buttonHeight = 50;
            float buttonYStart = Gdx.graphics.getHeight() / 2;

            batch.draw(startGameButton, (Gdx.graphics.getWidth() - buttonWidth) / 2, buttonYStart + 63, buttonWidth, buttonHeight);
            batch.draw(newGameButton, (Gdx.graphics.getWidth() - buttonWidth) / 2, buttonYStart + 63 - 10 - buttonHeight, buttonWidth, buttonHeight);
            batch.draw(levelsButton, (Gdx.graphics.getWidth() - buttonWidth) / 2, buttonYStart + 63 - 10 - buttonHeight - 63, buttonWidth, buttonHeight);

            if (Gdx.input.isTouched()) {
                float touchX = Gdx.input.getX();
                float touchY = Gdx.graphics.getHeight() - Gdx.input.getY();

                if (touchX >= settingsIconX && touchX <= settingsIconX + 84 && touchY >= settingsIconY && touchY <= settingsIconY + 84) {
                    settingScreen.toggle();
                }
            }

            settingScreen.render();
        }
        batch.end();
    }

    @Override
    public void dispose() {
        batch.dispose();
        loadingImage.dispose();
        mainScreenImage.dispose();
        homeIcon.dispose();
        startGameButton.dispose();
        newGameButton.dispose();
        levelsButton.dispose();
        settingsIcon.dispose();
        musicButton.dispose();
        settingScreen.dispose();
    }
}
