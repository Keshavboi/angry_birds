package io.github.angry_birds;

public class ScoreCounter {
    private int currentScore;
    private int totalScore;

    public void updateScore(int scoreDelta) {}
    public void resetScore() {}
}
