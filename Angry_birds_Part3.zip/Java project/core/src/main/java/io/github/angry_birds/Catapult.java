package io.github.angry_birds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.*;

public class Catapult {

    private Body body;
    private Sprite sprite;
    private Rectangle boundingBox;
    private boolean isDragging; // Flag to check if being dragged

    public Catapult(World world, String texturePath, float x, float y) {
        Texture texture = new Texture(texturePath);
        sprite = new Sprite(texture);
        sprite.setSize(55, 100); // Catapult size
        sprite.setPosition(x, y);

        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.StaticBody;
        bodyDef.position.set((x + sprite.getWidth() / 2) / 100f,
            (y + sprite.getHeight() / 2) / 100f);
        body = world.createBody(bodyDef);

        PolygonShape shape = new PolygonShape();
        shape.setAsBox((sprite.getWidth() / 2) / 100f,
            (sprite.getHeight() / 2) / 100f);

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        body.createFixture(fixtureDef);
        body.setUserData("catapult");

        shape.dispose();

        boundingBox = new Rectangle(x, y, sprite.getWidth(), sprite.getHeight());
        isDragging = false;
    }
    public void update() {
        // Remove input handling for dragging the catapult.
        // Sync sprite position with the Box2D body (static, so position remains constant).
        sprite.setPosition(
            body.getPosition().x * 100 - sprite.getWidth() / 2,
            body.getPosition().y * 100 - sprite.getHeight() / 2
        );
        boundingBox.setPosition(sprite.getX(), sprite.getY());
    }

//    public void update() {
//        // Mouse interaction
//        if (Gdx.input.isButtonPressed(Input.Buttons.LEFT)) {
//            float mouseX = Gdx.input.getX();
//            float mouseY = Gdx.graphics.getHeight() - Gdx.input.getY(); // Invert Y-axis for LibGDX
//            if (boundingBox.contains(mouseX, mouseY)) {
//                isDragging = true;
//            }
//        } else {
//            isDragging = false; // Release the drag
//        }
//
//        if (isDragging) {
//            float mouseX = Gdx.input.getX() / 100f;
//            float mouseY = (Gdx.graphics.getHeight() - Gdx.input.getY()) / 100f;
//            body.setTransform(mouseX, mouseY, 0); // Update Box2D position
//        }
//
//        // Sync sprite position with Box2D body
//        sprite.setPosition(
//            body.getPosition().x * 100 - sprite.getWidth() / 2,
//            body.getPosition().y * 100 - sprite.getHeight() / 2
//        );
//        boundingBox.setPosition(sprite.getX(), sprite.getY());
//    }

    public void draw(SpriteBatch batch) {
        sprite.draw(batch);
    }

    public Rectangle getBoundingBox() {
        return boundingBox;
    }

    public Body getBody() {
        return body;
    }

    public void dispose() {
        sprite.getTexture().dispose();
    }
}
