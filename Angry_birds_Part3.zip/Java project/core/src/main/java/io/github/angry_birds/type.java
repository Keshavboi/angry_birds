package io.github.angry_birds;

public enum type{
    Wood,Ice,Stone;
}

