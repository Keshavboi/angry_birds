package io.github.angry_birds;

public enum shape{
    Plank, Box, square;
}
