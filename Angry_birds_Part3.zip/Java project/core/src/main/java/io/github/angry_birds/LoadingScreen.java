package io.github.angry_birds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.ScreenUtils;

public class LoadingScreen implements Screen {
    private SpriteBatch batch;
    private Texture StartingImage;
    private Texture TextImg;
    private float timeElapsed;
    private boolean isLoading;

    private Main maingame;

    public LoadingScreen(Main maingame) {
        this.maingame=maingame;
    }
    @Override
    public void show() {
        batch = new SpriteBatch();

        StartingImage = new Texture("redscreen.jpg");  // The loading screen image
        TextImg = new Texture("loadingtext.png");
        timeElapsed = 0f;
        isLoading = true;
    }

    @Override
    public void render(float v) {
        ScreenUtils.clear(0.15f, 0.15f, 0.2f, 1f);
        batch.begin();

        timeElapsed += Gdx.graphics.getDeltaTime();

//        batch.begin();
        if (isLoading) {
            // Draw the loading screen image
//            batch.draw(loadingImage, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
            batch.draw(StartingImage, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
            batch.draw(TextImg, (float) (Gdx.graphics.getWidth() /2 )-140,100);

            // After 2 seconds, switch to the main screen
            if (timeElapsed > 2) {
                isLoading = false;  // Switch to the main screen
                timeElapsed = 0;    // Reset time for any future use
            }
        } else {
            maingame.setScreen(new Playscreen(maingame));
        }
        batch.end();
    }

    @Override
    public void resize(int i, int i1) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        StartingImage.dispose();
        batch.dispose();
    }
}
