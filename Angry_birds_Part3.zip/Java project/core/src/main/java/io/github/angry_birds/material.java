package io.github.angry_birds;

import java.awt.desktop.ScreenSleepEvent;

public class material {
    type type;
    shape shape;
    int durability;

    public material (type type, shape shape, int durability){
            this.type=type;
            this.shape=shape;
            this.durability=durability;
    }
    public void damageTaken(){
        durability--;
    }

    public int getDurability() {
        return durability;
    }

    public io.github.angry_birds.shape getShape() {
        return shape;
    }

    public io.github.angry_birds.type getType() {
        return type;
    }

    public void setDurability(int durability) {
        this.durability = durability;
    }

    public void setShape(io.github.angry_birds.shape shape) {
        this.shape = shape;
    }

    public void setType(io.github.angry_birds.type type) {
        this.type = type;
    }
}

