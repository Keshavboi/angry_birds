package io.github.angry_birds;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.utils.Array;

import java.util.ArrayList;

public class Trajectory implements ContactListener {
    private Bird lastBird;
    private float initialAngle;
    private float initialSpeed;
    private ArrayList<Body> toRemove = new ArrayList<>();
    public void calculateTrajectory() {}


    @Override
    public void beginContact(Contact contact) {
        if (contact.isTouching()) {
            Fixture attacker = contact.getFixtureA();
            Fixture defender = contact.getFixtureB();
            WorldManifold worldManifold = contact.getWorldManifold();
            if ("enemy".equals(defender.getUserData())) {
                Vector2 vel1 = attacker.getBody().getLinearVelocityFromWorldPoint(worldManifold.getPoints()[0]);
                Vector2 vel2 = defender.getBody().getLinearVelocityFromWorldPoint(worldManifold.getPoints()[0]);
                Vector2 impactVelocity = vel1.sub(vel2);
                if (Math.abs(impactVelocity.x) > 1 || Math.abs(impactVelocity.y) > 1) {
                    toRemove.add(defender.getBody());
                }
            }
        }
    }

    @Override
    public void endContact(Contact contact) {

    }

    @Override
    public void preSolve(Contact contact, Manifold manifold) {

    }

    @Override
    public void postSolve(Contact contact, ContactImpulse contactImpulse) {

    }
}
