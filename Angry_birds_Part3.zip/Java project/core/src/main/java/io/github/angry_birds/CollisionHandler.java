//package io.github.angry_birds;
//
//import com.badlogic.gdx.physics.box2d.*;
//import com.badlogic.gdx.math.Vector2;
//
//public class CollisionHandler implements ContactListener {
//
//    @Override
//    public void beginContact(Contact contact) {
//        // Retrieve bodies involved in the collision
//        Body bodyA = contact.getFixtureA().getBody();
//        Body bodyB = contact.getFixtureB().getBody();
//        // Check user data to identify objects
//        Object userDataA = bodyA.getUserData();
//        Object userDataB = bodyB.getUserData();
//
//        if (userDataA == null || userDataB == null) return;
//
//        // Handle collisions based on object types
//        if (userDataA instanceof Bird && userDataB instanceof Block) {
//            handleBirdBlockCollision((Bird) userDataA, (Block) userDataB, contact);
//        } else if (userDataA instanceof Block && userDataB instanceof Bird) {
//            handleBirdBlockCollision((Bird) userDataB, (Block) userDataA, contact);
//        } else if (userDataA instanceof Bird && userDataB instanceof Pig) {
//            handleBirdPigCollision((Bird) userDataA, (Pig) userDataB, contact);
//        } else if (userDataA instanceof Pig && userDataB instanceof Bird) {
//            handleBirdPigCollision((Bird) userDataB, (Pig) userDataA, contact);
//        } else if (userDataA instanceof Block && userDataB instanceof Block) {
//            handleBlockBlockCollision((Block) userDataA, (Block) userDataB, contact);
//        } else if (userDataA instanceof Pig && userDataB instanceof Pig) {
//            handlePigPigCollision((Pig) userDataA, (Pig) userDataB, contact);
//        } else if (userDataA instanceof Pig && userDataB instanceof Block) {
//            handlePigBlockCollision((Pig) userDataA, (Block) userDataB, contact);
//        } else if (userDataA instanceof Block && userDataB instanceof Pig) {
//            handlePigBlockCollision((Pig) userDataB, (Block) userDataA, contact);
//        } else if ("ground".equals(userDataA) && userDataB instanceof Bird) {
//            handleBirdGroundCollision((Bird) userDataB, contact);
//        } else if (userDataA instanceof Bird && "ground".equals(userDataB)) {
//            handleBirdGroundCollision((Bird) userDataA, contact);
//        } else if ("ground".equals(userDataA) && userDataB instanceof Block) {
//            handleBlockGroundCollision((Block) userDataB, contact);
//        } else if (userDataA instanceof Block && "ground".equals(userDataB)) {
//            handleBlockGroundCollision((Block) userDataA, contact);
//        } else if ("ground".equals(userDataA) && userDataB instanceof Pig) {
//            handlePigGroundCollision((Pig) userDataB, contact);
//        } else if (userDataA instanceof Pig && "ground".equals(userDataB)) {
//            handlePigGroundCollision((Pig) userDataA, contact);
//        }
//    }
//
//    @Override
//    public void endContact(Contact contact) {
//        // Handle end of collisions if needed
//    }
//
//    @Override
//    public void preSolve(Contact contact, Manifold oldManifold) {
//        // Adjust collision properties if needed
//    }
//
//    @Override
//    public void postSolve(Contact contact, ContactImpulse impulse) {
//        // Handle collision resolution (e.g., apply impulses) if needed
//    }
//
//    // Collision handlers
//
//    private void handleBirdBlockCollision(Bird bird, Block block, Contact contact) {
//        applyDamage(block, 20);  // Example: block takes damage
//        applyBirdImpulse(bird.getBody(), block.getBody(), contact, 0.8f);  // Correct impulse for bird-block collision
//    }
//
//    private void handleBirdPigCollision(Bird bird, Pig pig, Contact contact) {
//        applyDamage(pig, 30);  // Example: pig takes more damage
//        applyBirdImpulse(bird.getBody(), pig.getBody(), contact, 0.8f);  // Correct impulse for bird-pig collision
//    }
//
//    private void handleBlockBlockCollision(Block blockA, Block blockB, Contact contact) {
//        applyImpulse(blockA.getBody(), blockB.getBody(), contact);
//    }
//
//    private void handlePigPigCollision(Pig pigA, Pig pigB, Contact contact) {
//        applyImpulse(pigA.getBody(), pigB.getBody(), contact);
//    }
//
//    private void handlePigBlockCollision(Pig pig, Block block, Contact contact) {
//        applyDamage(block, 10);  // Block takes some damage
//        applyImpulse(pig.getBody(), block.getBody(), contact);
//    }
//
//    private void handleBirdGroundCollision(Bird bird, Contact contact) {
//        // Ensure we are only applying damage once when the bird hits the ground
//        if (!bird.isOnGround()) {
//            bird.setOnGround(true); // Mark the bird as having hit the ground
//            bird.takeDamage(50);     // Apply significant damage to the bird when it hits the ground
//        }
//
//        // Apply friction to slow down the bird's movement upon collision with the ground
//        applyGroundFriction(bird.getBody());
//    }
//
//    private void handleBlockGroundCollision(Block block, Contact contact) {
//        applyGroundFriction(block.getBody());
//    }
//
//    private void handlePigGroundCollision(Pig pig, Contact contact) {
//        pig.takeDamage(20);  // Pig takes some damage on hitting the ground
//        applyGroundFriction(pig.getBody());
//    }
//
//    // Utility methods
//
//    private void applyImpulse(Body bodyA, Body bodyB, Contact contact) {
//        Vector2 contactPoint = contact.getWorldManifold().getPoints().length > 0 ? contact.getWorldManifold().getPoints()[0] : new Vector2();
//        Vector2 bodyACenter = bodyA.getWorldCenter();
//        Vector2 bodyBCenter = bodyB.getWorldCenter();
//
//        // Calculate impulse direction
//        Vector2 impulse = new Vector2(bodyBCenter.x - bodyACenter.x, bodyBCenter.y - bodyACenter.y).nor().scl(5f);
//
//        // Apply impulses to both bodies
//        bodyA.applyLinearImpulse(impulse, contactPoint, true);
//        bodyB.applyLinearImpulse(impulse.scl(-1), contactPoint, true);
//    }
//
//    private void applyBirdImpulse(Body bird, Body otherBody, Contact contact, float restitution) {
//        // Get the relative velocity between the two bodies at the point of collision
//        Vector2 birdVelocity = bird.getLinearVelocity();
//        Vector2 otherVelocity = otherBody.getLinearVelocity();
//
//        // Calculate the collision normal (direction of the impact)
//        Vector2 contactPoint = contact.getWorldManifold().getPoints()[0];
//        Vector2 birdToOther = otherBody.getWorldCenter().cpy().sub(bird.getWorldCenter()).nor(); // Direction from bird to other body
//
//        // Calculate the relative velocity in the direction of the normal
//        float velocityAlongNormal = birdVelocity.dot(birdToOther) - otherVelocity.dot(birdToOther);
//
//        // If the bodies are moving apart (no need for impulse), return
//        if (velocityAlongNormal > 0) {
//            return;
//        }
//
//        // Calculate impulse scalar using the coefficient of restitution (restitution)
//        float massBird = bird.getMass();
//        float massOther = otherBody.getMass();
//        float impulseMagnitude = -(1 + restitution) * velocityAlongNormal / (1 / massBird + 1 / massOther);
//
//        // Apply impulse to both bodies
//        Vector2 impulse = birdToOther.scl(impulseMagnitude);
//        bird.applyLinearImpulse(impulse, contactPoint, true);
//        otherBody.applyLinearImpulse(impulse.scl(-1), contactPoint, true);
//    }
//
//    private void applyGroundFriction(Body body) {
//        Vector2 velocity = body.getLinearVelocity();
//        float frictionFactor = 0.9f;  // Simulate gradual stop
//        body.setLinearVelocity(velocity.scl(frictionFactor));
//    }
//
//    private void applyDamage(Damageable entity, float damage) {
//        entity.takeDamage(damage);  // Damageable interface ensures objects like Pig, Block, and Bird can take damage
//    }
//}
