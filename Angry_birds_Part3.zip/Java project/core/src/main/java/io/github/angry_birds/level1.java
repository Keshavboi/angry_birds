package io.github.angry_birds;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
public class level1 implements Screen {
    private final Main maingame ;
    private World world;
    private Box2DDebugRenderer debugRenderer;
    private OrthographicCamera camera;
    private Viewport viewport;
    private Texture texture;

    private static final float WORLD_WIDTH = 1280f;
    private static final float WORLD_HEIGHT = 840f;
    public level1(Main maingame) {
        this.maingame = maingame;
        camera = new OrthographicCamera();
        viewport = new FitViewport(WORLD_WIDTH, WORLD_HEIGHT, camera);
//        camera.setToOrtho(false, 800 / 32f, 480 / 32f); // Example scaling
        // Initialize Box2D world
        world = new World(new Vector2(0, -9.8f), true);


        BodyDef bodyDef = new BodyDef();
        bodyDef.position.set(160/100f,120/100f);
        bodyDef.type= BodyDef.BodyType.StaticBody;
        Body body = world.createBody(bodyDef);

        PolygonShape shape = new PolygonShape();
        shape.setAsBox(50,5);

        FixtureDef fixtureDef=new FixtureDef();
        fixtureDef.shape=shape;
        body.createFixture(fixtureDef);



        // Debug renderer for visualization
        debugRenderer = new Box2DDebugRenderer();

        // Camera setup

    }

    @Override
    public void render(float delta) {
        // Clear the screen
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Update the world
        world.step(1 / 60f, 6, 2);

        // Render Box2D debug visuals
        debugRenderer.render(world, camera.combined);
    }

    @Override
    public void resize(int width, int height) {
//        viewport.update(width, height);
        camera.update();
    }

    @Override
    public void dispose() {
        world.dispose();
        debugRenderer.dispose();
    }

    // Other required methods (empty implementations for now)
    @Override public void show() {}
    @Override public void hide() {}
    @Override public void pause() {}
    @Override public void resume() {}
}
