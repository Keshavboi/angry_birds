package io.github.angry_birds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.ScreenUtils;

public class Mainscreen implements Screen {
    private Stage stage;
    private Main mainGame;

    private SpriteBatch batch;
    private Texture mainScreenImage;

    // Button textures
    private Texture MenuIcon;
    private boolean isRotated = false;

    private Texture playbutton;
    private Texture settingsIcon;
    private Texture SoundButton;
    private Texture MuteButton;
    private boolean isMuted = false;

    public Mainscreen(Main mainGame){
        this.mainGame=mainGame;
    }

    @Override
    public void show() {

        stage = new Stage();
        Gdx.input.setInputProcessor(stage);

        mainScreenImage = new Texture("mainpage.png");

        // Load the image texture for the button
        playbutton = new Texture("play.png");

        float buttonXStart = Gdx.graphics.getWidth() / 2;
//        float buttonYStart = Gdx.graphics.getHeight() / 2;

//

        // Create an Image using the texture
        Image buttonImage = new Image(playbutton);

        buttonImage.setPosition(buttonXStart-180, 100);
        // Add a click listener to the image button
        buttonImage.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                // Logic to handle button click, such as switching screens
                mainGame.setScreen(new LevelScreen(mainGame)); // Switch to Screen2
            }
        });

        stage.addActor(buttonImage);
        float menuIconX = 30; // Top-left corner
        float menuIconY = Gdx.graphics.getHeight() - 100;

        SoundButton = new Texture("volume.png");
        MuteButton = new Texture("mute.png");

        Image Volumebutton = new Image(SoundButton);

        Volumebutton.setPosition(menuIconX,menuIconY-90);
        Volumebutton.setVisible(false);
        // Add a click listener to the image button
        Volumebutton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                // Logic to handle button click, such as switching screens
                isMuted = !isMuted;

                // Update button texture based on mute state
                if (isMuted) {
                    Volumebutton.setDrawable(new TextureRegionDrawable(new TextureRegion(MuteButton)));
                    // Additional code to mute sound if necessary
                }
                else{
                    Volumebutton.setDrawable(new TextureRegionDrawable(new TextureRegion(SoundButton)));
                }
            }

        });

        stage.addActor(Volumebutton);

        settingsIcon = new Texture("settings_icon.png");
        Image SettingButton = new Image(settingsIcon);

        SettingButton.setPosition(menuIconX,menuIconY-180);
        SettingButton.setVisible(false);

        SettingButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                mainGame.setScreen(new SettingScreen(mainGame));
            }

        });
        stage.addActor(SettingButton);

        MenuIcon = new Texture("menu.png");


         // Adjust according to your icon size
        Image Menubutton = new Image(MenuIcon);

        Menubutton.setPosition(menuIconX,menuIconY);

        Menubutton.setOrigin(Menubutton.getWidth() / 2, Menubutton.getHeight() / 2);

        Menubutton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                isRotated=!isRotated;
                Volumebutton.setVisible(isRotated);
                SettingButton.setVisible(isRotated);

                if(isRotated) {
                    Menubutton.rotateBy(90);

                }
                else {
                    Menubutton.rotateBy(-90);

                }
            }

        });

        stage.addActor(Menubutton);



        batch = new SpriteBatch();
    }

    @Override
    public void render(float v) {

        ScreenUtils.clear(0, 0, 0, 1f);
        batch.begin();

        batch.draw(mainScreenImage, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        float buttonWidth = 200;
        float buttonHeight = 200;
        float buttonYStart = Gdx.graphics.getHeight() / 2; // Center vertically
        float buttonXStart = Gdx.graphics.getWidth() / 2; // Center horizontally
//
//        batch.draw(PlayButton, 500, 350, buttonWidth, buttonHeight);
        batch.end();

        stage.act(v);
        stage.draw();

    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        stage.dispose();
        mainScreenImage.dispose();

        batch.dispose();
    }
}
