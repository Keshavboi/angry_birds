package io.github.angry_birds;

public interface Damageable {
    void takeDamage(float damage);

    boolean isDestroyed();
}
