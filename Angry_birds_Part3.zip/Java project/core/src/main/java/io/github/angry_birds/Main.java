package io.github.angry_birds;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class Main extends Game {


    private SpriteBatch batch;
    private Texture background;
    private Texture bird1;
    private Texture catapult;
    private Texture pig1;
    private Texture ice;
    private Texture rock;
    private Texture wood;

//    Level1 lv1Screen;
    @Override
    public void create() {

        setScreen(new Playscreen(this));
//        batch = new SpriteBatch();
//        background = new Texture("playscreen1.jpeg");
//        bird1 = new Texture("redbird.png");
//        catapult = new Texture("catapult.png");
//        pig1 = new Texture("pig1.png");
//        ice = new Texture("iceblock.png");
//        rock = new Texture("rock.png");
//        wood = new Texture("wood.png");
    }

//    @Override
//    public void resize(int width, int height) {
//        super.resize(width, height);
//    }
//
//    @Override
//    public void render() {
////        ScreenUtils.clear(0, 0, 0, 1f);
////        batch.begin();
////        batch.draw(background, 0, 0);
////        batch.draw(bird1,100,180,70,65);
////        batch.draw(catapult,200,180,100,280);
////        batch.draw(bird1,220,380,70,65);
////        batch.draw(pig1,1000,245,70,65);
//////        batch.draw(ice,1200,180,65,65);
////        batch.draw(rock,1000,180,65,65);
////        batch.draw(rock,1000,310,65,65);
////        batch.draw(wood,1065,180,65,65);
////        batch.draw(wood,1065,245,65,65);
////        batch.draw(wood,935,180,65,65);
////        batch.draw(wood,935,245,65,65);
////        batch.draw(rock,935,310,65,65);
////        batch.draw(rock,1065,310,65,65);
////        batch.end();
//    }
//
//    @Override
//    public void dispose() {
////        batch.dispose();
////        background.dispose();
//    }
////
//    public void setScreen(Playscreen playscreen) {
//    }
}
