package io.github.angry_birds.lwjgl3;

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;
import io.github.angry_birds.Main; // En`sure this is your MainGame class

/** Launches the desktop (LWJGL3) application. */
public class Lwjgl3Launcher {
    public static void main(String[] args) {
        if (StartupHelper.startNewJvmIfRequired()) return; // Handles macOS/Windows support.
        createApplication();
    }

    private static Lwjgl3Application createApplication() {
        return new Lwjgl3Application(new Main(), getDefaultConfiguration());
    }

    private static Lwjgl3ApplicationConfiguration getDefaultConfiguration() {
        Lwjgl3ApplicationConfiguration configuration = new Lwjgl3ApplicationConfiguration();
        configuration.setTitle("Angry Birds");

        // Enable Vsync to limit FPS to display refresh rate
        configuration.useVsync(false);

        // Optional: Limit FPS to the monitor's refresh rate + 1
        configuration.setForegroundFPS(Lwjgl3ApplicationConfiguration.getDisplayMode().refreshRate + 1);

        // Set the window size to 1280x840
        configuration.setWindowedMode(1280, 840);

        // Make the window non-resizable (adjust this if you want a resizable window)
        configuration.setResizable(false);

        // Set window icon (ensure the path is correct for your project)
        configuration.setWindowIcon("icon.png");

        return configuration;
    }
}
