package io.github.AngryBird.me;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;

public class Bird {
    private Texture texture;
    private Vector2 position;
    private float speed;
    private String type; // Different Type of Bird

    public Bird(Texture texture, Vector2 position, float speed, String type) {
        this.texture = texture;
        this.position = position;
        this.speed = speed;
        this.type = type;
    }

    public Texture getTexture() {
        return texture;
    }

    public Vector2 getPosition() {
        return position;
    }

    public float getSpeed() {
        return speed;
    }

    public String getType() {
        return type;
    }

    public void setPosition(Vector2 position) {
        this.position = position;
    }

    public void update() {
        // Update bird's position based on speed and other logic
        position.add(speed, 0); // Example movement, adjust as needed
    }
}
