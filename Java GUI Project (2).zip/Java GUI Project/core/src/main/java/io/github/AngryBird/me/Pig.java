package io.github.AngryBird.me;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;

public class Pig {
    private Texture texture;
    private Vector2 position;
    private int health;

    public Pig(Texture texture, Vector2 position, int health) {
        this.texture = texture;
        this.position = position;
        this.health = health;
    }

    public Texture getTexture() {
        return texture;
    }

    public Vector2 getPosition() {
        return position;
    }

    public int getHealth() {
        return health;
    }

    public void setPosition(Vector2 position) {
        this.position = position;
    }

    public void takeDamage(int damage) {
        health -= damage;
        if (health <= 0) {
            // Handle pig defeat
        }
    }
}
