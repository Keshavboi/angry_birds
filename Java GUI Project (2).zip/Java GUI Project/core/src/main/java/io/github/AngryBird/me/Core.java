package io.github.AngryBird.me;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

public class Core extends ApplicationAdapter {
    private SpriteBatch batch;
    private Texture loadingImage;
    private Texture mainScreenImage;
    private Texture popupImage;
    private float timeElapsed;
    private boolean isLoading;
    private boolean isSettingsOpen;

    private Texture homeIcon, startGameButton, newGameButton, levelsButton, settingsIcon, musicButton;
    private Texture closeButton;
    private Texture termsPrivacyButton, supportButton, creditsButton, eraseDataButton;

    private float homeIconX, homeIconY, musicButtonX, musicButtonY, settingsIconX, settingsIconY;

    @Override
    public void create() {
        batch = new SpriteBatch();
        loadingImage = new Texture("1.png");
        mainScreenImage = new Texture("Angry Bird 1.png");
        timeElapsed = 0f;
        isLoading = true;
        isSettingsOpen = false;

        homeIcon = new Texture("home_icon.png");
        startGameButton = new Texture("start_game_button.jpg");
        newGameButton = new Texture("new_game_button.png");
        levelsButton = new Texture("levels_button.png");
        settingsIcon = new Texture("settings_icon.jpg");
        musicButton = new Texture("music_button.jpg");

        closeButton = new Texture("close_button.png");
        termsPrivacyButton = new Texture("terms_privacy.png");
        supportButton = new Texture("support.png");
        creditsButton = new Texture("credit.png");
        eraseDataButton = new Texture("Erase data.png");

        popupImage = new Texture("settingbackground.png");

        homeIconX = 30;
        homeIconY = Gdx.graphics.getHeight() - 100;
        musicButtonX = Gdx.graphics.getWidth() - 100;
        musicButtonY = Gdx.graphics.getHeight() - 100;
        settingsIconX = 20;
        settingsIconY = 30;
    }

    @Override
    public void render() {
        ScreenUtils.clear(0.15f, 0.15f, 0.2f, 1f);
        batch.begin();

        timeElapsed += Gdx.graphics.getDeltaTime();

        if (isLoading) {
            batch.draw(loadingImage, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
            if (timeElapsed > 1) {
                isLoading = false;
                timeElapsed = 0;
            }
        } else {
            batch.draw(mainScreenImage, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
            batch.draw(homeIcon, homeIconX, homeIconY, 84, 84);
            batch.draw(settingsIcon, settingsIconX, settingsIconY, 84, 84);
            batch.draw(musicButton, musicButtonX, musicButtonY, 84, 84);

            float buttonWidth = 200;
            float buttonHeight = 50;
            float buttonYStart = Gdx.graphics.getHeight() / 2;

            batch.draw(startGameButton, (Gdx.graphics.getWidth() - buttonWidth) / 2, buttonYStart + 63, buttonWidth, buttonHeight);
            batch.draw(newGameButton, (Gdx.graphics.getWidth() - buttonWidth) / 2, buttonYStart + 63 - 10 - buttonHeight, buttonWidth, buttonHeight);
            batch.draw(levelsButton, (Gdx.graphics.getWidth() - buttonWidth) / 2, buttonYStart + 63 - 10 - buttonHeight - 63, buttonWidth, buttonHeight);

            if (isSettingsOpen) {
                batch.draw(popupImage, (Gdx.graphics.getWidth() - popupImage.getWidth()) / 2, (Gdx.graphics.getHeight() - popupImage.getHeight()) / 2);
                drawSettingsPopup();
            }

            if (Gdx.input.isTouched()) {
                float touchX = Gdx.input.getX();
                float touchY = Gdx.graphics.getHeight() - Gdx.input.getY();

                if (touchX >= settingsIconX && touchX <= settingsIconX + 84 && touchY >= settingsIconY && touchY <= settingsIconY + 84) {
                    isSettingsOpen = !isSettingsOpen;
                }

                if (isSettingsOpen) {
                    float closeButtonSize = 70;
                    float closeButtonX = (Gdx.graphics.getWidth() - popupImage.getWidth()) / 2 + popupImage.getWidth() - closeButtonSize - 10;
                    float closeButtonY = (Gdx.graphics.getHeight() - popupImage.getHeight()) / 2 + popupImage.getHeight() - closeButtonSize - 10;

                    if (touchX >= closeButtonX && touchX <= closeButtonX + closeButtonSize && touchY >= closeButtonY && touchY <= closeButtonY + closeButtonSize) {
                        isSettingsOpen = false;
                    }
                }
            }
        }
        batch.end();
    }

    private void drawSettingsPopup() {
        float popupWidth = popupImage.getWidth();
        float popupHeight = popupImage.getHeight();
        float buttonWidth = 300;
        float buttonHeight = 60;
        float buttonX = (popupWidth - buttonWidth) / 2 + (Gdx.graphics.getWidth() - popupWidth) / 2;
        float buttonYStart = (Gdx.graphics.getHeight() - popupHeight) / 2 + popupHeight - 80;

        batch.draw(termsPrivacyButton, buttonX, buttonYStart, buttonWidth, buttonHeight);
        batch.draw(supportButton, buttonX, buttonYStart - 70, buttonWidth, buttonHeight);
        batch.draw(creditsButton, buttonX, buttonYStart - 140, buttonWidth, buttonHeight);
        batch.draw(eraseDataButton, buttonX, buttonYStart - 210, buttonWidth, buttonHeight);

        float closeButtonSize = 100;
        float closeButtonX = (Gdx.graphics.getWidth() - popupWidth) / 2 + popupWidth - closeButtonSize - 20;
        float closeButtonY = (Gdx.graphics.getHeight() - popupHeight) / 2 + popupHeight - closeButtonSize - 20;
        batch.draw(closeButton, closeButtonX, closeButtonY, closeButtonSize, closeButtonSize);
    }

    @Override
    public void dispose() {
        batch.dispose();
        loadingImage.dispose();
        mainScreenImage.dispose();
        homeIcon.dispose();
        startGameButton.dispose();
        newGameButton.dispose();
        levelsButton.dispose();
        settingsIcon.dispose();
        musicButton.dispose();
        closeButton.dispose();
        termsPrivacyButton.dispose();
        supportButton.dispose();
        creditsButton.dispose();
        eraseDataButton.dispose();
        popupImage.dispose();
    }
}
