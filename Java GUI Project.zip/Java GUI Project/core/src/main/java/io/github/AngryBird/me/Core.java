package io.github.AngryBird.me;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class Core extends ApplicationAdapter {
    private SpriteBatch batch;
    private Texture loadingImage;
    private Texture mainScreenImage;
    private float timeElapsed;
    private boolean isLoading;

    // Button textures
    private Texture homeIcon;
    private Texture startGameButton;
    private Texture newGameButton;
    private Texture levelsButton;
    private Texture settingsIcon;
    private Texture musicButton;

    // Button positions
    private float homeIconX, homeIconY;
    private float musicButtonX, musicButtonY;
    private float settingsIconX, settingsIconY;

    @Override
    public void create() {
        batch = new SpriteBatch();

        loadingImage = new Texture("1.png");  // The loading screen image
        mainScreenImage = new Texture("Angry Bird 1.png");  // The main screen image
        timeElapsed = 0f;
        isLoading = true;  // Start with the loading screen

        // Load button textures
        homeIcon = new Texture("home_icon.png");
        startGameButton = new Texture("start_game_button.jpg");
        newGameButton = new Texture("new_game_button.png");
        levelsButton = new Texture("levels_button.png");
        settingsIcon = new Texture("settings_icon.jpg");
        musicButton = new Texture("music_button.jpg");

        // Set positions for the icons and buttons
        homeIconX = 30; // Top-left corner
        homeIconY = Gdx.graphics.getHeight() - 100; // Adjust according to your icon size

        musicButtonX = Gdx.graphics.getWidth() - 100; // Top-right corner
        musicButtonY = Gdx.graphics.getHeight() - 100; // Adjust according to your icon size

        settingsIconX = 20; // Bottom-left corner
        settingsIconY = 30; // Adjust according to your icon size

    }

    @Override
    public void render() {
        ScreenUtils.clear(0.15f, 0.15f, 0.2f, 1f);
        batch.begin();

        timeElapsed += Gdx.graphics.getDeltaTime();

//        batch.begin();
        if (isLoading) {
            // Draw the loading screen image
            batch.draw(loadingImage, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

            // After 2 seconds, switch to the main screen
            if (timeElapsed > 2) {
                isLoading = false;  // Switch to the main screen
                timeElapsed = 0;    // Reset time for any future use
            }
        } else {
            // Draw the main screen image
            batch.draw(mainScreenImage, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
            // Draw icons
            batch.draw(homeIcon, homeIconX, homeIconY, 84, 84); // Home icon
            batch.draw(settingsIcon, settingsIconX, settingsIconY, 84, 84); // Settings icon



        // Draw buttons in the center
        float buttonWidth = 200;
        float buttonHeight = 50;
        float buttonYStart = Gdx.graphics.getHeight() / 2; // Center vertically

        batch.draw(startGameButton, (Gdx.graphics.getWidth() - buttonWidth) / 2, buttonYStart + 60, buttonWidth, buttonHeight);
        batch.draw(newGameButton, (Gdx.graphics.getWidth() - buttonWidth) / 2, buttonYStart, buttonWidth, buttonHeight);
        batch.draw(levelsButton, (Gdx.graphics.getWidth() - buttonWidth) / 2, buttonYStart - 60, buttonWidth, buttonHeight);

        batch.draw(musicButton, musicButtonX, musicButtonY, 84, 84); // Music icon
    }
        batch.end();
    }

    @Override
    public void dispose() {
        batch.dispose();
        loadingImage.dispose();
        mainScreenImage.dispose();
        homeIcon.dispose();
        startGameButton.dispose();
        newGameButton.dispose();
        levelsButton.dispose();
        settingsIcon.dispose();
        musicButton.dispose();
    }
}
