package io.github.angry_birds;

public class GameState {

    private String currentScreen;
    private boolean paused;

    public void pauseGame() {}
    public void resumeGame() {}
    public void checkGameOver() {}

}
