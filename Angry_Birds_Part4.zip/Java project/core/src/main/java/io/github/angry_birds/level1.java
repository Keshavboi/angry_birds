package io.github.angry_birds;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

public class level1 extends Playscreen implements Screen {
//    private final Main maingame;
    private World world;
    private Box2DDebugRenderer debugRenderer;
    private Bird redBird;
    private SpriteBatch batch;
    private Texture background;
    private Catapult catapult;
    private OrthographicCamera camera;
    private Viewport viewport;
    private boolean isPaused = false;
    private Pig pig;
    private Block block;
    private Body groundBody; // Ground Box2D body
    private CollisionHandler collisionHandler;
    private static final float WORLD_WIDTH = 1280f;
    private static final float WORLD_HEIGHT = 840f;

    private final Vector2 startPosition = new Vector2(210, 280); // Initial position of the bird

    public level1(Main maingame) {
        super(maingame);

        camera = new OrthographicCamera();
        viewport = new FitViewport(WORLD_WIDTH, WORLD_HEIGHT, camera);


//        world.setContactListener(collisionHandler);
    }

    private void createGround() {
        // Define ground body
        BodyDef groundBodyDef = new BodyDef();
        groundBodyDef.type = BodyDef.BodyType.StaticBody; // Static body doesn't move
        groundBodyDef.position.set(WORLD_WIDTH / 2 / 100f, 1f); // Centered, slightly above bottom

        // Create ground body in the world
        groundBody = world.createBody(groundBodyDef);

        // Define the ground shape
        PolygonShape groundShape = new PolygonShape();
        groundShape.setAsBox(WORLD_WIDTH / 2 / 100f, 0.5f); // Box shape, 0.5m tall

        // Create fixture for the ground
        FixtureDef groundFixtureDef = new FixtureDef();
        groundFixtureDef.shape = groundShape;
        groundFixtureDef.friction = 2f; // Slight friction for interactions
        groundFixtureDef.restitution = 0.2f; // Small bounciness

        groundBody.createFixture(groundFixtureDef);
        groundShape.dispose(); // Clean up shape
    }

    @Override
    public void initialize() {
        world = new World(new Vector2(0, -9.8f), true);
        debugRenderer = new Box2DDebugRenderer();

        batch = new SpriteBatch();
        background = new Texture("playscreen1.jpeg");
        catapult = new Catapult(world, "catapult.png", 190, 180);
        redBird = new Bird(world, "redbird.png", startPosition.x, startPosition.y, 4);
        pig=new Pig(world,"pig1.png",1000,280,3);
        block = new Block(world,"wood.png",1000,200,2);
        createGround(); // Initialize ground

        handleBirdLaunch();
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        if (isPaused) return;

        ScreenUtils.clear(0, 0, 0, 1f);
        world.step(1 / 60f, 6, 2);

        batch.begin();
        batch.draw(background, 0, 0);

        if(!redBird.isDead()){
            redBird.draw(batch);
            redBird.update();
        }
        catapult.draw(batch);

        if(!pig.isDead()){
            pig.draw(batch);
            pig.update();
        }

        if(!block.isBroken()){
            block.draw(batch);
            block.update();
        }
        batch.end();

        debugRenderer.render(world, camera.combined);

        // Update camera position to follow the bird
//        camera.position.set(
//            Math.max(redBird.getBody().getPosition().x * 100, WORLD_WIDTH / 2),
//            WORLD_HEIGHT / 2, 0
//        );
//        camera.update();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height);
        camera.update();
    }

    @Override
    public void pause() {
        isPaused = true;
    }

    @Override
    public void resume() {
        isPaused = false;
    }

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        world.dispose();
        catapult.dispose();
        debugRenderer.dispose();
        batch.dispose();
        background.dispose();
        redBird.dispose();
    }
}
