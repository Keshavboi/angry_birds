package io.github.angry_birds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.ScreenUtils;

public class SettingScreen implements Screen {

    private Stage stage;
    private Main maingame;
    private SpriteBatch batch;

    private Texture settingScreen;
    private Texture backbutton;
    private Texture termsPrivacyButton;
    private Texture supportButton;
    private Texture creditsButton;

    public SettingScreen(Main maingame){
        this.maingame=maingame;
    }

    @Override
    public void show() {
        stage = new Stage();
        Gdx.input.setInputProcessor(stage);

        batch = new SpriteBatch();

        settingScreen = new Texture("pause.jpg");

        backbutton = new Texture("back.png");

        float backIconX = 30; // Top-left corner
        float backIconY = Gdx.graphics.getHeight() - 100;

        Image backIcon = new Image(backbutton);

        backIcon.setPosition(backIconX,backIconY);

        backIcon.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                // Logic to handle button click, such as switching screens
                maingame.setScreen(new Mainscreen(maingame)); // Switch to Screen2
            }
        });

        stage.addActor(backIcon);

        termsPrivacyButton = new Texture("terms_privacy.png");
        supportButton = new Texture("support.png");
        creditsButton = new Texture("credit.png");
    }

    @Override
    public void render(float v) {

        float resumeButtonX = (float) Gdx.graphics.getWidth() / 2-150;
        float resumeButtonY = (float) Gdx.graphics.getHeight() / 2;


        ScreenUtils.clear(0, 0, 0, 1f);
        batch.begin();
        batch.draw(settingScreen, 0, 0,Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        batch.draw(termsPrivacyButton,resumeButtonX,resumeButtonY+50);
        batch.draw(creditsButton,resumeButtonX,resumeButtonY-70);
        batch.draw(supportButton,resumeButtonX,resumeButtonY-190);

        batch.end();

        stage.act(v);
        stage.draw();


    }

    @Override
    public void resize(int i, int i1) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        stage.dispose();
        settingScreen.dispose();
        creditsButton.dispose();
        supportButton.dispose();
        termsPrivacyButton.dispose();
        batch.dispose();

    }
}
