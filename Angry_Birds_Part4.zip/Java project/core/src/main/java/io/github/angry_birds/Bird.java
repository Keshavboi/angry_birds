

package io.github.angry_birds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;

public class Bird {
    private Body body;          // Box2D body for physics
    private Sprite sprite;      // Visual representation
    private Rectangle boundingBox; // Bounding box for interaction
    private boolean isLaunched = false;
    private int health;

    public Bird(World world, String texturePath, float x, float y, int health) {
        Texture texture = new Texture(texturePath);
        sprite = new Sprite(texture);
        sprite.setSize(35, 32);
        sprite.setPosition(x, y);

        // Create Box2D body
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody; // Dynamic for gravity and movement
        bodyDef.position.set(x / 100f, y / 100f);    // Convert to Box2D units
        body = world.createBody(bodyDef);

        CircleShape shape = new CircleShape();
        shape.setRadius(16/100f); // Radius in Box2D units

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.density = 1f;
        fixtureDef.friction = 2f;
        fixtureDef.restitution = 0.3f; // Slight bounciness
        body.createFixture(fixtureDef);
        body.setUserData(this);

        shape.dispose();

        this.health=health;
        // Bounding box for mouse interactions
//        boundingBox = new Rectangle(x, y, sprite.getWidth(), sprite.getHeight());
    }

    public void update() {
        // Sync sprite position with Box2D body
        sprite.setPosition(
            body.getPosition().x * 100 - sprite.getWidth() / 2,
            body.getPosition().y * 100 - sprite.getHeight() / 2
        );

        sprite.setOrigin(
            body.getPosition().x * 100 - sprite.getWidth() / 2,
            body.getPosition().y * 100 - sprite.getHeight() / 2
        );
//        boundingBox.setPosition(sprite.getX(), sprite.getY());

        // Debug: Log bird position
//        System.out.println("Bird position: " + body.getPosition());
    }

    public void launchAtAngle(float speed, float angleDegrees) {
        if (!isLaunched) {
//            float angleRadians = (float) Math.toRadians(angleDegrees);
            float velocityX = speed * (float) Math.cos(angleDegrees);
            float velocityY = speed * (float) Math.sin(angleDegrees);
            body.applyForceToCenter(new Vector2(velocityX,velocityY),true);
//            body.setLinearVelocity(velocityX, velocityY);
            isLaunched = true;
            System.out.println("" +
                "Bird launched at angle " + angleDegrees + " with speed " + speed);
        }
    }


    public void draw(SpriteBatch batch) {
        sprite.draw(batch);
    }

    public void takeDamage() {
         --health;
    }

    public boolean isDead(){
        return health <= 0;
    }

    public Rectangle getBoundingBox() {
        return boundingBox;
    }

    public Body getBody() {
        return body;
    }

    public void dispose() {
        sprite.getTexture().dispose();
    }
}
