package io.github.angry_birds;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;

public class SlingShot{
    private Vector2 fixedPosition;  // The fixed point (anchor)
    private Vector2 movingPosition; // The moving point (stretched end)
    private Sprite[] springTextures; // Array of textures for different spring lengths
    private float maxStretch; // Maximum stretch limit
    private float stretchFactor; // Factor to determine how stretched the spring is
    private Sprite currentSpring; // Current spring texture based on stretch
    private float springLength;
    private float rotationAngle; // Rotation angle for the spring
    private boolean dragging; // Whether the spring is being dragged
    private Vector2 initialMovingPosition;

    public SlingShot(Vector2 fixedPosition, float maxStretch, String[] texturePaths) {
        this.fixedPosition = fixedPosition;
        this.movingPosition = new Vector2(fixedPosition); // Initially, it's at the same position
        this.initialMovingPosition = new Vector2(fixedPosition);
        this.maxStretch = maxStretch;

        // Load textures for different stretch distances
        springTextures = new Sprite[texturePaths.length];
        for (int i = 0; i < texturePaths.length; i++) {
            springTextures[i] = new Sprite(new Texture(texturePaths[i]));
        }

        // Initially, the spring is not stretched
        updateSpring();
    }
    public void startDrag(Vector2 initialPosition) {
        this.dragging = true;
        this.initialMovingPosition = new Vector2(movingPosition); // Save the initial position
    }
    // When dragging stops, use a simple lerp (linear interpolation) to smoothly transition back to the original state
    public void update(Vector2 newPosition) {
        if (dragging) {
            // Update spring position and stretch
            this.movingPosition.set(newPosition);
            this.springLength = fixedPosition.dst(movingPosition);
            updateSpring();

            // Update rotation
            rotationAngle = fixedPosition.angleDeg(movingPosition);
        } else {
            // Smoothly reset position using lerp (linear interpolation) or tweening
            movingPosition.lerp(initialMovingPosition, 0.1f); // Adjust the factor for speed
            springLength = fixedPosition.dst(movingPosition);
            updateSpring();
            rotationAngle = 0; // Reset rotation
        }
    }

    private void updateSpring() {
        // Calculate the index for the spring texture based on the stretch length
        int index = Math.min(springTextures.length - 1, (int) (springLength / maxStretch * (springTextures.length - 1)));

        // Set the current spring texture
        currentSpring = springTextures[index];

        // You can also change the size of the spring based on stretch
        currentSpring.setSize(springLength, currentSpring.getHeight());
    }

    public void draw(SpriteBatch batch) {
        // Draw the spring texture with the calculated rotation
        batch.draw(currentSpring, fixedPosition.x, fixedPosition.y,
            currentSpring.getWidth() / 2, currentSpring.getHeight() / 2, // Origin at the center
            currentSpring.getWidth(), currentSpring.getHeight(),
            1, 1, rotationAngle);
    }

    public void stopDrag() {
        this.dragging = false; // Stop dragging
    }
    public Vector2 getMovingPosition() {
        return movingPosition;
    }
    public void dispose() {
        for (Sprite springTexture : springTextures) {
            springTexture.getTexture().dispose(); // Dispose the texture used in the sprite
        }
    }
}
