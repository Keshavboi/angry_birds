package io.github.angry_birds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.ScreenUtils;

public class PauseScreen implements Screen {
    private Stage stage;
    private SpriteBatch batch;

    private Texture resumebutton;
    private Texture restartbutton;
    private Texture levelsButton;

    private Texture HomeButton;
    private Texture SettingsButton;
    private Texture VolumeButton;
    private Texture MuteButton;
    private boolean isMuted = false;

    private Texture buttonTexture;
    private Texture pauseScreen;

    private float resumeButtonX;
    private float resumeButtonY;

    private Main maingame;
    public PauseScreen(Main maingame) {
        this.maingame=maingame;
    }

    @Override
    public void show() {
        stage = new Stage();
        Gdx.input.setInputProcessor(stage);

        batch = new SpriteBatch();

        pauseScreen = new Texture("pause.jpg");
        resumebutton= new Texture("resume.png");
        restartbutton = new Texture("restart.png");
        HomeButton = new Texture("home.png");
        levelsButton = new Texture("levels.png");
        SettingsButton = new Texture("settings_icon.png");
        VolumeButton = new Texture("volume.png");
        MuteButton = new Texture("mute.png");

        resumeButtonX = (float) Gdx.graphics.getWidth() /2;
        resumeButtonY = (float) Gdx.graphics.getHeight() /2;

        Image resumeIcon = new Image(resumebutton);
        resumeIcon.setPosition(resumeButtonX-150,resumeButtonY+50);

        resumeIcon.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {

                maingame.setScreen(new Playscreen(maingame));
            }
        });

        stage.addActor(resumeIcon);

        Image restartIcon = new Image(restartbutton);
        restartIcon.setPosition(resumeButtonX-150,resumeButtonY-70);

        restartIcon.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {

                maingame.setScreen(new Playscreen(maingame));
            }
        });

        stage.addActor(restartIcon);

        Image levelsIcon = new Image(levelsButton);
        levelsIcon.setPosition(resumeButtonX-150,resumeButtonY-190);

        levelsIcon.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {

                maingame.setScreen(new LevelScreen(maingame));
            }
        });

        stage.addActor(levelsIcon);

        Image homeIcon = new Image(HomeButton);
        homeIcon.setPosition(resumeButtonX-150,resumeButtonY-290);

        homeIcon.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {

                maingame.setScreen(new ExitingScreen(maingame));
            }
        });

        stage.addActor(homeIcon);

        Image settingIcon = new Image(SettingsButton);
        settingIcon.setPosition(resumeButtonX-45,resumeButtonY-290);

        settingIcon.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {

                maingame.setScreen(new SettingScreen(maingame));
            }
        });

        stage.addActor(settingIcon);

        Image volumeIcon = new Image(VolumeButton);
        volumeIcon.setPosition(resumeButtonX+60,resumeButtonY-290);

        volumeIcon.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                // Logic to handle button click, such as switching screens
                isMuted = !isMuted;

                // Update button texture based on mute state
                if (isMuted) {
                    volumeIcon.setDrawable(new TextureRegionDrawable(new TextureRegion(MuteButton)));
                    // Additional code to mute sound if necessary
                }
                else{
                    volumeIcon.setDrawable(new TextureRegionDrawable(new TextureRegion(VolumeButton)));
                }
            }

        });

        stage.addActor(volumeIcon);



    }

    @Override
    public void render(float v) {

        ScreenUtils.clear(0, 0, 0, 1f);
        batch.begin();
        batch.draw(pauseScreen, 0, 0,Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        batch.end();

        stage.act(v);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        stage.dispose();
        pauseScreen.dispose();
        batch.dispose();
    }
}
