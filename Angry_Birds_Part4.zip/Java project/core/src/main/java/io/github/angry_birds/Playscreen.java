package io.github.angry_birds;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

import java.util.ArrayList;
import java.util.List;

public class Playscreen implements Screen {
    private final Main maingame;
    private World world;
    private Box2DDebugRenderer debugRenderer;
    private Bird redBird;
    private SpriteBatch batch;
    private Texture background;
    private Catapult catapult;
    private OrthographicCamera camera;
    private Viewport viewport;
    private boolean isPaused = false;
    private Pig pig;
    private Block block;
    private Body groundBody; // Ground Box2D body
    private static final float WORLD_WIDTH = 1280f;
    private static final float WORLD_HEIGHT = 840f;
    public List<Bird> birdList = new ArrayList<>();
    public List<Pig> pigList = new ArrayList<>();
    public List<Block> blockList = new ArrayList<>();
    public List<Body> DeadBodyList = new ArrayList<>();
    public ScoreCounter scoreCounter;
    private final Vector2 startPosition = new Vector2(210, 280); // Initial position of the bird

    public Playscreen(Main maingame) {
        this.maingame = maingame;

        camera = new OrthographicCamera();
        viewport = new FitViewport(WORLD_WIDTH, WORLD_HEIGHT, camera);

        world = new World(new Vector2(0, -9.8f), true);
        debugRenderer = new Box2DDebugRenderer();

        initialize();

        world.setContactListener(new CollisionHandler(this));
//
//        birdList.add(redBird);
//        pigList.add(pig);
//        blockList.add(block);

    }

    private void createGround() {
        // Define ground body
        BodyDef groundBodyDef = new BodyDef();
        groundBodyDef.type = BodyDef.BodyType.StaticBody; // Static body doesn't move
        groundBodyDef.position.set(WORLD_WIDTH / 2 / 100f, 1f); // Centered, slightly above bottom

        // Create ground body in the world
        groundBody = world.createBody(groundBodyDef);

        // Define the ground shape
        PolygonShape groundShape = new PolygonShape();
        groundShape.setAsBox(WORLD_WIDTH / 2 / 100f, 0.5f); // Box shape, 0.5m tall

        // Create fixture for the ground
        FixtureDef groundFixtureDef = new FixtureDef();
        groundFixtureDef.shape = groundShape;
        groundFixtureDef.friction = 2f; // Slight friction for interactions
        groundFixtureDef.restitution = 0.2f; // Small bounciness

        groundBody.createFixture(groundFixtureDef);
        groundShape.dispose(); // Clean up shape
    }

    public void initialize() {
        batch = new SpriteBatch();
        background = new Texture("playscreen1.jpeg");
        catapult = new Catapult(world, "catapult.png", 190, 180);
        redBird = new Bird(world, "redbird.png", startPosition.x, startPosition.y, 4);
        pig=new Pig(world,"pig1.png",1000,280,3);
        block = new Block(world,"wood.png",1000,200,3);
        createGround(); // Initialize ground

        handleBirdLaunch();
    }

    public void handleBirdLaunch(){
        Gdx.input.setInputProcessor(new InputAdapter() {
            @Override
            public boolean touchDown(int screenX, int screenY, int pointer, int button) {
                if (button == Input.Buttons.LEFT) {
                    Vector3 touchPos = new Vector3(screenX, screenY, 0);
                    camera.unproject(touchPos);

                    // Calculate the distance between the bird and the touch position
                    Vector2 touchVector = new Vector2(screenX, screenY);
                    Vector2 birdPosition = new Vector2(startPosition.x, startPosition.y);
                    float distance = touchVector.dst(birdPosition); // Get the distance

                    // Calculate the vector from bird to touch position
                    Vector2 direction = birdPosition.sub(touchVector);

                    // Calculate the angle between the vector and the horizontal ground (X-axis)
                    float angle = MathUtils.atan2(direction.y, direction.x); // This gives the angle in radians

                    // Adjust the speed based on the distance, with a cap to prevent too high speed
                    float speed = distance /5; // Scale the speed (adjust divisor as needed)
//                    speed = MathUtils.clamp(speed, 5f, 20f); // Ensure speed is within a range (5 to 20)

                    // Launch the bird with the calculated angle and speed
                    redBird.launchAtAngle(speed, angle); // Launch the bird with the calculated angle and speed

                    return true;
                }
                return false;
            }
        });

    }



    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        if (isPaused) return;

        ScreenUtils.clear(0, 0, 0, 1f);
        world.step(1 / 60f, 6, 2);

        batch.begin();
        batch.draw(background, 0, 0);

        if(!redBird.isDead()){
            redBird.draw(batch);
            redBird.update();
        }
        catapult.draw(batch);

        if(!pig.isDead()){
            pig.draw(batch);
            pig.update();
        }

        if(!block.isBroken()){
            block.draw(batch);
            block.update();
        }
        batch.end();
        destroyBodies();
        debugRenderer.render(world, camera.combined);

        // Update camera position to follow the bird
//        camera.position.set(
//            Math.max(redBird.getBody().getPosition().x * 100, WORLD_WIDTH / 2),
//            WORLD_HEIGHT / 2, 0
//        );
//        camera.update();
    }
    public void addToDeadList(Body body, Object object){
        DeadBodyList.add(body);
        if(object instanceof Block){
            Block block = (Block) object;
            block.dispose();
        }else if(object instanceof Bird){
            Bird bird = (Bird) object;
            bird.dispose();
        }else if(object instanceof Pig){
            Pig pig = (Pig) object;
            pig.dispose();
        }
    }
    public void destroyBodies(){
        for(Body body : DeadBodyList){
            world.destroyBody(body);
        }
        DeadBodyList.clear();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height);
        camera.update();
    }

    @Override
    public void pause() {
        isPaused = true;
    }

    @Override
    public void resume() {
        isPaused = false;
    }

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        world.dispose();
        catapult.dispose();
        debugRenderer.dispose();
        batch.dispose();
        background.dispose();
        redBird.dispose();

    }
}
