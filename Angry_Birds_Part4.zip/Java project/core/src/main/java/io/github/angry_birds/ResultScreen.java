package io.github.angry_birds;

public class ResultScreen {
}
