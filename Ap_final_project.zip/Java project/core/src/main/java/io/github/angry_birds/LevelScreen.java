package io.github.angry_birds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.ScreenUtils;

public class LevelScreen implements Screen {

    private SpriteBatch batch;
    private Stage stage;
    private Texture backbutton;
    private Texture levelScreen;
    private Texture level1;
    private Texture level2;
    private Texture level3;

    private Main maingame;

    public LevelScreen(Main maingame) {
        this.maingame=maingame;
    }
    @Override
    public void show() {
        stage = new Stage();
        Gdx.input.setInputProcessor(stage);

        levelScreen = new Texture("level.png");

        level1 = new Texture("Lv1.png");
        level2 = new Texture("Lv2new.png");
        level3 = new Texture("Lv3new.png");
//        batch.draw(level2, 500, 300);
//        batch.draw(level3, 800, 300);


        Image lv2 = new Image(level2);
//        buttonImage.setScale(buttonWidth,buttonHeight);

        lv2.setPosition(500, 300);

        lv2.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                // Logic to handle button click, such as switching screens
                maingame.setScreen(new Playscreen(maingame)); // Switch to Screen2
            }
        });
        stage.addActor(lv2);
        Image lv3 = new Image(level3);
//        buttonImage.setScale(buttonWidth,buttonHeight);

        lv3.setPosition(800, 300);

        lv3.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                // Logic to handle button click, such as switching screens
                maingame.setScreen(new Playscreen(maingame)); // Switch to Screen2
            }
        });
        stage.addActor(lv3);

        Image buttonImage = new Image(level1);
//        buttonImage.setScale(buttonWidth,buttonHeight);

        buttonImage.setPosition(200, 300);

        buttonImage.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                // Logic to handle button click, such as switching screens
                maingame.setScreen(new Playscreen(maingame)); // Switch to Screen2
            }
        });
        stage.addActor(buttonImage);




        backbutton = new Texture("back.png");

        float backIconX = 30; // Top-left corner
        float backIconY = Gdx.graphics.getHeight() - 100;

        Image backIcon = new Image(backbutton);

        backIcon.setPosition(backIconX,backIconY);

        backIcon.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                // Logic to handle button click, such as switching screens
                maingame.setScreen(new Mainscreen(maingame)); // Switch to Screen2
            }
        });

        stage.addActor(backIcon);

        batch = new SpriteBatch();

    }

    @Override
    public void render(float v) {
        ScreenUtils.clear(0, 0, 0, 1f);
        batch.begin();

        batch.draw(levelScreen, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

        batch.end();

        stage.act(v);
        stage.draw();

    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }
    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        level1.dispose();
        level2.dispose();
        level3.dispose();
        stage.dispose();
        levelScreen.dispose();
        batch.dispose();
    }
}
