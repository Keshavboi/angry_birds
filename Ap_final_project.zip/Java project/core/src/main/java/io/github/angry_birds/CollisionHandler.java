package io.github.angry_birds;

import com.badlogic.gdx.physics.box2d.*;
import java.util.ArrayList;
import java.util.List;

public class CollisionHandler implements ContactListener {
    private Playscreen playscreen;
    private List<Body> DeadBodyList = new ArrayList<>();

    public CollisionHandler(Playscreen playscreen) {
        this.playscreen = playscreen;

    }

    @Override
    public void beginContact(Contact contact) {
        // Retrieve bodies involved in the collision
        Body bodyA = contact.getFixtureA().getBody();
        Body bodyB = contact.getFixtureB().getBody();
        // Check user data to identify objects
        Object userDataA = bodyA.getUserData();
        Object userDataB = bodyB.getUserData();

        // Bird - Block
        if (userDataA instanceof Bird && userDataB instanceof Block) {
            handleCollision((Bird) userDataA, (Block) userDataB);
        } else if (userDataA instanceof Block && userDataB instanceof Bird) {
            handleCollision((Bird) userDataB, (Block) userDataA);
        }

        // Bird - Pig
        else if (userDataA instanceof Bird && userDataB instanceof Pig) {
            handleCollision((Bird) userDataA, (Pig) userDataB);
        } else if (userDataA instanceof Pig && userDataB instanceof Bird) {
            handleCollision((Bird) userDataB, (Pig) userDataA);
        }

        // Block - Block
        else if (userDataA instanceof Block && userDataB instanceof Block) {
            handleCollision((Block) userDataA, (Block) userDataB);
        }

        // Pig - Block
        else if (userDataA instanceof Pig && userDataB instanceof Block) {
            handleCollision((Pig) userDataA, (Block) userDataB);
        } else if (userDataA instanceof Block && userDataB instanceof Pig) {
            handleCollision((Pig) userDataB, (Block) userDataA);
        }

        // Bird - Ground
        else if (userDataA instanceof Bird && "ground".equals(userDataB)) {
            handleCollision((Bird) userDataA);
        } else if ("ground".equals(userDataA) && userDataB instanceof Bird) {
            handleCollision((Bird) userDataB);
        }

        // Block - Ground
        else if (userDataA instanceof Block && "ground".equals(userDataB)) {
            handleCollision((Block) userDataA);
        } else if ("ground".equals(userDataA) && userDataB instanceof Block) {
            handleCollision((Block) userDataB);
        }

        // Pig - Ground
        else if (userDataA instanceof Pig && "ground".equals(userDataB)) {
            handleCollision((Pig) userDataA);
        } else if ("ground".equals(userDataA) && userDataB instanceof Pig) {
            handleCollision((Pig) userDataB);
        }
    }

    private void handleCollision(Bird bird, Block block) {
        bird.takeDamage();
        block.takeDamage();
        bird.getBody().setLinearVelocity((bird.getBody().getLinearVelocity().x)/2,(bird.getBody().getLinearVelocity().y)/2);
        handleRemovalBird(bird);
        handleRemovalBlock(block);
    }

    private void handleCollision(Bird bird, Pig pig) {
        bird.takeDamage();
        pig.takeDamage();
        bird.getBody().setLinearVelocity((bird.getBody().getLinearVelocity().x)/2,(bird.getBody().getLinearVelocity().y)/2);
        handleRemovalBird(bird);
        handleRemovalPig(pig);
    }

    private void handleCollision(Block blockA, Block blockB) {
        blockA.takeDamage();
        blockB.takeDamage();
        handleRemovalBlock(blockA);
        handleRemovalBlock(blockB);
    }

    private void handleCollision(Pig pig, Block block) {
        pig.takeDamage();
        block.takeDamage();
        handleRemovalPig(pig);
        handleRemovalBlock(block);
    }

    private void handleCollision(Bird bird) {
        bird.takeDamage();
        handleRemovalBird(bird);
        bird.getBody().setLinearVelocity((bird.getBody().getLinearVelocity().x)/2,(bird.getBody().getLinearVelocity().y)/2);
    }

    private void handleCollision(Block block) {
        block.takeDamage();
        handleRemovalBlock(block);
    }

    private void handleCollision(Pig pig) {
        pig.takeDamage();
        handleRemovalPig(pig);
    }

    public void handleRemovalBlock(Block block) {
        if (block.isBroken()) {
            playscreen.blockList.remove(block);
            playscreen.addToDeadList(block.getBody(), block);
        }
    }

    public void handleRemovalBird(Bird bird) {
        if (bird.isDead()) {
            playscreen.birdList.remove(bird);
            playscreen.addToDeadList(bird.getBody(), bird);
        }
    }

    public void handleRemovalPig(Pig pig) {
        if (pig.isDead()) {
            playscreen.pigList.remove(pig);
            playscreen.addToDeadList(pig.getBody(), pig);
        }
    }

//    public void addToDeadList(Body body, Object object) {
//        DeadBodyList.add(body);
//        if (object instanceof Block) {
//            ((Block) object).dispose();
//        } else if (object instanceof Bird) {
//            ((Bird) object).dispose();
//        } else if (object instanceof Pig) {
//            ((Pig) object).dispose();
//        }
//    }
//
//    public void destroyBodies() {
//        for (Body body : DeadBodyList) {
//            world.destroyBody(body);
//        }
//        DeadBodyList.clear();
//    }

    @Override
    public void endContact(Contact contact) {
        // Handle end of collisions if needed
    }

    @Override
    public void preSolve(Contact contact, Manifold oldManifold) {
        // Adjust collision properties if needed
    }

    @Override
    public void postSolve(Contact contact, ContactImpulse impulse) {
        // Handle collision resolution if needed
    }
}
