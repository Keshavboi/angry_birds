package io.github.angry_birds;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;

import java.util.ArrayList;
import java.util.List;

/** {@link com.badlogic.gdx.ApplicationListener} implementation shared by all platforms. */
public class Main extends Game {


    private SpriteBatch batch;
    private Texture background;
    private Texture bird1;
    private Texture catapult;
    private Texture pig1;
    private Texture ice;
    private Texture rock;
    private Texture wood;
    public int CurrentlevelNo=1;
    public int NextlevelNo;

//    Level1 lv1Screen;
    @Override
    public void create() {

        setScreen(new StartingScreen(this));

    }

    public int getCurrentlevelNo() {
        return CurrentlevelNo;
    }

    public int getNextlevelNo() {
        return NextlevelNo;
    }

    public void setCurrentlevelNo(int currentlevelNo) {
        CurrentlevelNo = currentlevelNo;
    }

    public void setNextlevelNo(int nextlevelNo) {
        NextlevelNo = nextlevelNo;
    }
}
