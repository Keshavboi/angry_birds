package io.github.angry_birds;

public class ScoreCounter {
    private int currentScore;
    private int finalScore;

    public int getCurrentScore() {
        return currentScore;
    }

    public int getFinalScore() {
        return finalScore;
    }

    public void setCurrentScore(int currentScore) {
        this.currentScore = currentScore;
    }
    public boolean hasWon(int totalScore){
        return currentScore==totalScore;
    }


    public void updateScore(int scoreDelta) {}
    public void resetScore() {}
}
