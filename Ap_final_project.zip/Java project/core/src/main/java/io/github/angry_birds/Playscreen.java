package io.github.angry_birds;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

import java.util.ArrayList;
import java.util.List;

public class Playscreen implements Screen {
    private final Main maingame;
    private World world;
    private Box2DDebugRenderer debugRenderer;
    private Bird redBird;
    private SpriteBatch batch;
    private Texture background;
    private Catapult catapult;
    private OrthographicCamera camera;
    private Viewport viewport;
    private boolean isPaused = false;
    private Texture backbutton;
    private Pig pig;
    private Block block;
    private Body groundBody; // Ground Box2D body
    private static final float WORLD_WIDTH = 1280f;
    private static final float WORLD_HEIGHT = 840f;
    public List<Bird> birdList = new ArrayList<>();
    public List<Pig> pigList = new ArrayList<>();
    public List<Block> blockList = new ArrayList<>();
    public List<Body> DeadBodyList = new ArrayList<>();
    public ScoreCounter scoreCounter;
    private boolean islaunched = false;
    private float backIconX = 30; // Top-left corner
    private float backIconY = Gdx.graphics.getHeight() - 100;

    private final Vector2 startPosition = new Vector2(210, 280); // Initial position of the bird

    public Playscreen(Main maingame) {
        this.maingame = maingame;

        camera = new OrthographicCamera();
        viewport = new FitViewport(WORLD_WIDTH, WORLD_HEIGHT, camera);

        world = new World(new Vector2(0, -9.8f), true);
        debugRenderer = new Box2DDebugRenderer();
        initialize();

        world.setContactListener(new CollisionHandler(this));
        maingame.setCurrentlevelNo(1);
        maingame.setNextlevelNo(2);

//        birdList.add(redBird);
//        pigList.add(pig);
//        blockList.add(block);

    }

    private void createGround() {
        // Define ground body
        BodyDef groundBodyDef = new BodyDef();
        groundBodyDef.type = BodyDef.BodyType.StaticBody; // Static body doesn't move
        groundBodyDef.position.set(WORLD_WIDTH / 2 / 100f, 1.1f); // Centered, slightly above bottom

        // Create ground body in the world
        groundBody = world.createBody(groundBodyDef);

        // Define the ground shape
        PolygonShape groundShape = new PolygonShape();
        groundShape.setAsBox(WORLD_WIDTH / 2 / 100f, 0.5f); // Box shape, 0.5m tall

        // Create fixture for the ground
        FixtureDef groundFixtureDef = new FixtureDef();
        groundFixtureDef.shape = groundShape;
        groundFixtureDef.friction = 2; // Slight friction for interactions
        groundFixtureDef.restitution = 0.1f; // Small bounciness

        groundBody.createFixture(groundFixtureDef);
        groundShape.dispose(); // Clean up shape
    }

    public void initialize() {
        batch = new SpriteBatch();

        background = new Texture("playscreen1.jpeg");
        catapult = new Catapult(world, "catapult.png", 190, 180);
//        redBird = new Bird(world, "redbird.png", startPosition.x, startPosition.y, 4);
//        pig=new Pig(world,"pig1.png",1000,280,3);
//        block = new Block(world,"wood.png",1000,200,3);
        if(maingame.CurrentlevelNo==1) {
            Level1(world, birdList, pigList, blockList);
        }
        if(maingame.CurrentlevelNo==2) {
            Level2(world, birdList, pigList, blockList);
        }
        if(maingame.CurrentlevelNo==3) {
            Level3(world, birdList, pigList, blockList);
        }

        createGround(); // Initialize ground


        for (int i = 0; i < birdList.size(); i++) {
            Bird birds = birdList.get(i);
            if (!birds.isLaunched && !birds.onground) {
                handleBirdLaunch(birds);
                birds.getBody().setTransform(new Vector2(210 / 100f, 280 / 100f), 0);
            }
        }
        backbutton = new Texture("back.png");

    }
    public void handleBirdLaunch(Bird bird){
        Gdx.input.setInputProcessor(new InputAdapter() {
            @Override
            public boolean touchDown(int screenX, int screenY, int pointer, int button) {
                if (button == Input.Buttons.LEFT) {
                    if(screenX==backIconX/100f && screenY==backIconY/100f){
                        maingame.setCurrentlevelNo(maingame.NextlevelNo);
                        maingame.setNextlevelNo(++maingame.NextlevelNo);
                        maingame.setScreen(new LevelScreen(maingame));
                    }
                    Vector3 touchPos = new Vector3(screenX, screenY, 0);
                    camera.unproject(touchPos);

                    // Calculate the distance between the bird and the touch position
                    Vector2 touchVector = new Vector2(screenX, screenY);
                    Vector2 birdPosition = new Vector2(catapult.getBody().getPosition().x, 100);
                    float distance = touchVector.dst(birdPosition); // Get the distance

                    // Calculate the vector from bird to touch position
                    Vector2 direction = touchVector.sub(birdPosition);

                    // Calculate the angle between the vector and the horizontal ground (X-axis)
                    float angle = MathUtils.atan2(direction.y, direction.x); // This gives the angle in radians

                    // Adjust the speed based on the distance, with a cap to prevent too high speed
                    float speed = distance /20; // Scale the speed (adjust divisor as needed)
//                    speed = MathUtils.clamp(speed, 5f, 20f); // Ensure speed is within a range (5 to 20)

                    // Launch the bird with the calculated angle and speed
                    bird.launchAtAngle(speed, angle); // Launch the bird with the calculated angle and speed
//                    birdList.get(i+1).getBody().setTransform(new Vector2(210/100f,280/100f),0);
                    return true;
                }
                return false;
            }
        });
    }

    public void Level1(World world, List<Bird> birdArrayList,List<Pig> pigList,List<Block> blockList) {

        birdArrayList.add(new Bird(world,"redbird.png",210,280,1));
        birdArrayList.add(new Bird(world,"redbird.png",150,180,1));
        birdArrayList.add(new Bird(world,"redbird.png",100,180,1));

        pigList.add(new Pig(world,"pig1.png",1000,340,3));
        pigList.add(new Pig(world,"pig1.png",900,340,3));

        blockList.add(new Block(world,"rock.png",900,270,6));
        blockList.add(new Block(world,"wood.png",900,200,4));
        blockList.add(new Block(world,"rock.png",1000,270,6));
        blockList.add(new Block(world,"wood.png",1000,200,4));
    }
    public void Level2(World world, List<Bird> birdArrayList,List<Pig> pigList,List<Block> blockList) {
        birdArrayList.add(new Bird(world,"redbird.png",210,280,1));
        birdArrayList.add(new Bird(world,"redbird.png",150,180,1));
        birdArrayList.add(new Bird(world,"redbird.png",100,180,1));

        pigList.add(new Pig(world,"pig1.png",1040,340,3));
        pigList.add(new Pig(world,"pig1.png",900,340,3));
        pigList.add(new Pig(world,"pig1.png",970,270,3));

        blockList.add(new Block(world,"iceblock.png",970,374,3));
        blockList.add(new Block(world,"rock.png",900,270,6));
        blockList.add(new Block(world,"wood.png",900,200,4));
        blockList.add(new Block(world,"rock.png",1040,270,6));
        blockList.add(new Block(world,"wood.png",1040,200,4));
//        blockList.add(new Block(world,"wood.png",1000,200,3));
//        blockList.add(new Block(world,"wood.png",1000,270,3));
    }
    public void Level3(World world, List<Bird> birdArrayList,List<Pig> pigList,List<Block> blockList) {
        birdArrayList.add(new Bird(world,"redbird.png",210,280,2));
        birdArrayList.add(new Bird(world,"redbird.png",150,180,2));
        birdArrayList.add(new Bird(world,"redbird.png",100,180,2));

        pigList.add(new Pig(world,"pig1.png",1040,340,3));
        pigList.add(new Pig(world,"pig1.png",970,270,3));
        pigList.add(new Pig(world,"pig1.png",900,410,3));

        pigList.add(new Pig(world,"pig1.png",830,270,3));
        pigList.add(new Pig(world,"pig1.png",760,340,3))
        ;
        blockList.add(new Block(world,"iceblock.png",900,340,3));
        blockList.add(new Block(world,"iceblock.png",970,374,3));
        blockList.add(new Block(world,"iceblock.png",830,374,3));
        blockList.add(new Block(world,"rock.png",900,270,6));
        blockList.add(new Block(world,"wood.png",900,200,4));
        blockList.add(new Block(world,"rock.png",1040,270,6));
        blockList.add(new Block(world,"wood.png",1040,200,4));
        blockList.add(new Block(world,"wood.png",760,200,4));
        blockList.add(new Block(world,"wood.png",760,270,4));
        blockList.add(new Block(world,"rock.png",690,200,4));
        blockList.add(new Block(world,"rock.png",1110,200,4));
//        blockList.add(new Block(world,"wood.png",1000,200,3));
//        blockList.add(new Block(world,"wood.png",1000,270,3));
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        if (isPaused) return;

        ScreenUtils.clear(0, 0, 0, 1f);
        world.step(1 / 60f, 6, 2);

        batch.begin();
        batch.draw(background, 0, 0);
        for(Bird bird: birdList){
            if(!bird.isDead()){
                bird.draw(batch);
                bird.update();
            }
        }
        batch.draw(backbutton,backIconX,backIconY);

        catapult.draw(batch);

        for (Pig pig : pigList){
            if(!pig.isDead()){
                pig.draw(batch);
                pig.update();
            }
        }

        for(Block block: blockList){
            if(!block.isBroken()){
                block.draw(batch);
                block.update();
            }
        }

        batch.end();
        destroyBodies();
        debugRenderer.render(world, camera.combined);
        if(hasWin()){
            maingame.setScreen(new PauseScreen(maingame));
        }else if (hasLost()){
            maingame.setScreen(new ResultScreen(maingame));
        }
    }

    public boolean hasWin() {
        // Check if all pigs are gone (either dead or removed)
        for (Pig pig : pigList) {
            if (!pig.isDead()) {
                return false; // A pig is still alive
            }
        }
        return true; // All pigs are gone
    }

    public boolean hasLost() {
        // Check if all birds have launched
        for (Bird bird : birdList) {
            if (!bird.isLaunched) {
                return false; // A bird is still available to launch
            }
        }
        return true; // All birds have launched
    }

    public void addToDeadList(Body body, Object object){
        DeadBodyList.add(body);
        if(object instanceof Block){
            Block block = (Block) object;
            block.dispose();
        }else if(object instanceof Bird){
            Bird bird = (Bird) object;
            bird.dispose();
        }else if(object instanceof Pig){
            Pig pig = (Pig) object;
            pig.dispose();
        }
    }
    public void destroyBodies(){
        for(Body body : DeadBodyList){
            world.destroyBody(body);
        }
        DeadBodyList.clear();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height);
        camera.update();
    }

    @Override
    public void pause() {
        isPaused = true;
    }

    @Override
    public void resume() {
        isPaused = false;
    }

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        world.dispose();
        catapult.dispose();
        debugRenderer.dispose();
        batch.dispose();
        background.dispose();
//        redBird.dispose();

    }
}
