//package io.github.angry_birds;
//
//import com.badlogic.gdx.graphics.Texture;
//import com.badlogic.gdx.math.Vector2;
//
//public class SpecialBird extends Bird{
//    private String ability;
//    public SpecialBird(Texture texture, Vector2 position, float speed, String type) {
//        super(texture, position, speed, type);
//    }
//    public void useAbility() {}
//}
