

package io.github.angry_birds;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;

public class Block {
    private Body body;          // Box2D body for physics
    private Sprite sprite;      // Visual representation
    private Rectangle boundingBox; // Bounding box for interaction
    private boolean isLaunched = false;
    private int durability;
    public final int points = 50;

    public Block(World world, String texturePath, float x, float y, int durability) {
        Texture texture = new Texture(texturePath);
        sprite = new Sprite(texture);
        sprite.setSize(64, 64);
        sprite.setPosition(x, y);

        // Create Box2D body
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody; // Dynamic for gravity and movement
        bodyDef.position.set(x / 100f, y / 100f);    // Convert to Box2D units
        body = world.createBody(bodyDef);

        CircleShape shape = new CircleShape();
        shape.setRadius(32/100f); // Radius in Box2D units

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.density = 1f;
        fixtureDef.friction = 2f;
        fixtureDef.restitution = 0.3f; // Slight bounciness
        body.createFixture(fixtureDef);
        body.setUserData(this);

        shape.dispose();
        this.durability=durability;
        // Bounding box for mouse interactions
//        boundingBox = new Rectangle(x, y, sprite.getWidth(), sprite.getHeight());
    }

    public void update() {
        // Sync sprite position with Box2D body
        sprite.setPosition(
            body.getPosition().x * 100 - sprite.getWidth() / 2,
            body.getPosition().y * 100 - sprite.getHeight() / 2
        );

        sprite.setOrigin(
            body.getPosition().x * 100 - sprite.getWidth() / 2,
            body.getPosition().y * 100 - sprite.getHeight() / 2
        );
//        boundingBox.setPosition(sprite.getX(), sprite.getY());

        // Debug: Log bird position
//        System.out.println("Bird position: " + body.getPosition());
    }


    public void takeDamage() {
        --durability ;
    }

    public boolean isBroken(){
        return durability <= 0;
    }
    public void draw(SpriteBatch batch) {
        sprite.draw(batch);
    }

    public Rectangle getBoundingBox() {
        return boundingBox;
    }

    public Body getBody() {
        return body;
    }

    public void dispose() {
        sprite.getTexture().dispose();
    }

}
